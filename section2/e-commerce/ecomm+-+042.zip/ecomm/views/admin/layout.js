module.exports = ({ content }) => {
  return `
    <!DOCTYPE html>
    <html>
      <head>
      </head>
      <body>
        ${content}
      </body>
    </html
  `;
};
